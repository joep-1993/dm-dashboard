# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore


__protobuf__ = proto.module(
    package='google.ads.searchads360.v0.resources',
    marshal='google.ads.searchads360.v0',
    manifest={
        'AdGroupCriterionEffectiveLabel',
    },
)


class AdGroupCriterionEffectiveLabel(proto.Message):
    r"""A relationship between an ad group criterion and an effective
    label. An effective label is a label inherited or directly
    assigned to this ad group criterion.

    .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

    Attributes:
        resource_name (str):
            Immutable. The resource name of the ad group criterion
            effective label. Ad group criterion effective label resource
            names have the form:
            ``customers/{customer_id}/adGroupCriterionEffectiveLabels/{ad_group_id}~{criterion_id}~{label_id}``
        ad_group_criterion (str):
            Immutable. The ad group criterion to which
            the effective label is attached.

            This field is a member of `oneof`_ ``_ad_group_criterion``.
        label (str):
            Immutable. The effective label assigned to
            the ad group criterion.

            This field is a member of `oneof`_ ``_label``.
        owner_customer_id (int):
            Output only. The ID of the Customer which
            owns the effective label.

            This field is a member of `oneof`_ ``_owner_customer_id``.
    """

    resource_name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    ad_group_criterion: str = proto.Field(
        proto.STRING,
        number=2,
        optional=True,
    )
    label: str = proto.Field(
        proto.STRING,
        number=3,
        optional=True,
    )
    owner_customer_id: int = proto.Field(
        proto.INT64,
        number=4,
        optional=True,
    )


__all__ = tuple(sorted(__protobuf__.manifest))
